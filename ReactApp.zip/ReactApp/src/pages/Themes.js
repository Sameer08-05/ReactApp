import React, { useState, useEffect } from "react";
import "./Themes.css";

function Themes() {
    const [theme, setTheme] = useState(() => {
        return localStorage.getItem("theme") || "light";
    });

    const [variant, setVariant] = useState(() => {
        return localStorage.getItem("variant") || "aura";
    });

    const [btnState, setBtnState] = useState("default");

    const variants = ["crimson", "field", "aura"];
    const nextVariant = () => {
        const currentIndex = variants.indexOf(variant);
        const nextIndex = (currentIndex + 1) % variants.length;
        setVariant(variants[nextIndex]);
    };

    useEffect(() => {
        localStorage.setItem("theme", theme);
        localStorage.setItem("variant", variant);
    }, [theme, variant]);

    const uiColors = {
        aura: {
            light: {
                themeContainer: "#FFF5FF",
                squareContainer: "#FFD7F3",
                rectangle: "#FFF5FF",
                squares: ["#FFC891", "#FFD354"],
                buttons: {
                    light: {
                        default: "#FFD7F3",
                        hover: "#FFC891",
                        textColor: "#C92A4B",
                    },
                    aura: {
                        default: "#FFD354",
                        hover: "#FFE500",
                        textColor: "#C92A4B",
                    },
                },
            },
            dark: {
                themeContainer: "#700053",
                squareContainer: "#C92A4B",
                rectangle: "#A00153",
                squares: ["#E8543C", "#FC8127"],
                buttons: {
                    dark: {
                        default: "#A00153",
                        hover: "#E8543C",
                        textColor: "#FC8127",
                    },
                    aura: {
                        default: "#FFB003",
                        hover: "#FFE500",
                        textColor: "#C92A4B",
                    },
                },
            },
        },
        crimson: {
            light: {
                themeContainer: "#F2E6FF",
                squareContainer: "#FFA9E7",
                rectangle: "#F2E6FF",
                squares: ["#FF5A91", "#FF2D55"],
                buttons: {
                    light: {
                        default: "#FFA9E7",
                        hover: "#FF84C3",
                        textColor: "#581E64",
                    },
                    crimson: {
                        default: "#FF2D55",
                        hover: "#FF0000",
                        textColor: "#581E64",
                    },
                },
            },
            dark: {
                themeContainer: "#2A2152",
                squareContainer: "#581E64",
                rectangle: "#2A2152",
                squares: ["#8B0067", "#BB0059"],
                buttons: {
                    dark: {
                        default: "#581E64",
                        hover: "#8B0067",
                        textColor: "#BB0059",
                    },
                    crimson: {
                        default: "#E1003C",
                        hover: "#FF0000",
                        textColor: "#581E64",
                    },
                },
            },
        },
        field: {
            light: {
                themeContainer: "#CFFFFF",
                squareContainer: "#2FFFFF",
                rectangle: "#CFFFFF",
                squares: ["#00FFB6", "#00FF78"],
                buttons: {
                    light: {
                        default: "#2FFFFF",
                        hover: "#00FFB6",
                        textColor: "#005886",
                    },
                    field: {
                        default: "#00FF78",
                        hover: "#33FF00",
                        textColor: "#005886",
                    },
                },
            },
            dark: {
                themeContainer: "#003760",
                squareContainer: "#007B9E",
                rectangle: " #005886",
                squares: ["#009EA0", "#00C08D"],
                buttons: {
                    dark: {
                        default: "#005886",
                        hover: "#007B9E",
                        textColor: "#00C08D",
                    },
                    field: {
                        default: "#00E265",
                        hover: "#33FF00",
                        textColor: "#005886",
                    },
                },
            },
        },
    };

    const colors = uiColors[variant][theme];
    const buttonSet = colors.buttons;

    const lightBtn = buttonSet.light || {};
    const darkBtn = buttonSet.dark || {};
    const variantBtn = buttonSet[variant] || {};

    const themeBtnColor =
        theme === "light" ? lightBtn.default : darkBtn.default;
    const themeBtnHover =
        theme === "light" ? lightBtn.hover : darkBtn.hover;
    const themeBtnText =
        theme === "light" ? lightBtn.textColor : darkBtn.textColor;

    const variantBtnColor = variantBtn[btnState] || variantBtn.default || "#aaa";
    const variantBtnHover = variantBtn.hover || "#bbb";
    const variantBtnText = variantBtn.textColor || "#000";

    return (
        <div className="app">
            <div
                className="main-theme-container"
                style={{
                    backgroundColor:
                        theme === "dark"
                            ? {
                                aura: "#3C004B",
                                crimson: "#000B16",
                                field: "#001A33",
                            }[variant]
                            : "#fff",
                }}
            >
                <div className="title-parent">
                    <a
                        className="title"
                        style={{ color: theme === "light" ? "#000" : "#fff" }}
                    >
                        Prototype
                    </a>
                    <a
                        className="sub-title"
                        style={{ color: theme === "light" ? "#000" : "#fff" }}
                    >
                        theme and mode changer
                    </a>
                </div>

                <div
                    className="theme-container"
                    style={{ backgroundColor: colors.themeContainer }}
                >
                    <div
                        className="square-container"
                        style={{ backgroundColor: colors.squareContainer }}
                    >
                        <div
                            className="rectangle"
                            style={{ backgroundColor: colors.rectangle }}
                        ></div>

                        <div className="rectangle-container">
                            {colors.squares.map((color, index) => (
                                <div
                                    key={index}
                                    className="square"
                                    style={{ backgroundColor: color }}
                                ></div>
                            ))}
                        </div>
                    </div>

                    <div className="btn-container">
                        <div className="btn">
                            <a
                                className="bth-header-text"
                                style={{ color: theme === "light" ? "#000" : "#fff" }}
                            >
                                Sample testing
                            </a>
                        </div>

                        <div
                            className="btn"
                            onClick={() => setTheme(theme === "light" ? "dark" : "light")}
                            style={{
                                backgroundColor: themeBtnColor,
                                color: themeBtnText,
                                cursor: "pointer",
                            }}
                            onMouseEnter={(e) =>
                                (e.currentTarget.style.backgroundColor = themeBtnHover)
                            }
                            onMouseLeave={(e) =>
                                (e.currentTarget.style.backgroundColor = themeBtnColor)
                            }
                            onMouseDown={(e) => {
                                const textElement = e.currentTarget.querySelector(".btn-header-text");
                                if (textElement) textElement.style.fontWeight = "700";
                            }}
                            onMouseUp={(e) => {
                                const textElement = e.currentTarget.querySelector(".btn-header-text");
                                if (textElement) textElement.style.fontWeight = "400";
                            }}
                        >
                            <a
                                className="btn-header-text"
                                style={{
                                    color: themeBtnText,
                                    backgroundColor: "transparent",
                                    textDecoration: "none",
                                    fontSize: 12,
                                    fontWeight: 400,
                                }}
                            >
                                {theme === "light" ? "Light" : "Dark"}
                            </a>
                        </div>

                        <div
                            className="btn"
                            onClick={nextVariant}
                            onMouseEnter={() => setBtnState("hover")}
                            onMouseLeave={() => setBtnState("default")}
                            onMouseDown={() => setBtnState("click")}
                            onMouseUp={() => setBtnState("hover")}
                            style={{
                                backgroundColor: variantBtnColor,
                                color: variantBtnText,
                                cursor: "pointer",
                            }}
                        >
                            <a className="bth-header-text">
                                {variant.charAt(0).toUpperCase() + variant.slice(1)}
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Themes;
