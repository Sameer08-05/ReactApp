import React, { useState, useEffect, useRef } from 'react';
import './Post.css';

function Post({ username, message, isActions, allAuthors = [], isParentOpen }) {
    const [maxHeight, setMaxHeight] = useState('0px');
    const contentRef = useRef(null);

    useEffect(() => {
        if (contentRef.current) {
            if (isParentOpen) {
                setMaxHeight(contentRef.current.scrollHeight + 'px');
            } else {
                setMaxHeight('0px');
            }
        }
    }, [isParentOpen, message]);

    const renderMessageWithMentions = () => {
        if (allAuthors.length === 0) return message;

        const mentionRegex = new RegExp(`@(${allAuthors.join('|')})`, 'gi');
        const parts = message.split(mentionRegex);

        return parts.map((part, i) => {
            if (allAuthors.includes(part)) {
                return (
                    <span key={i} className="mention">
                        @{part}
                    </span>
                );
            }
            return <React.Fragment key={i}>{part}</React.Fragment>;
        });
    };

    return (
        <div
            className="post-container"
            style={{ maxHeight, overflow: 'hidden', transition: 'max-height 0.3s ease' }}
            ref={contentRef}
        >
            <div className="post">
                <div className="profile-box"></div>
                <div className="post-message">
                    <a className="username">{username}</a>
                    <a className="message">{renderMessageWithMentions()}</a>

                    {isActions && (
                        <div className="post-footer">
                            {isActions.like && (
                                <div className="actions-btn">
                                    <div className="titled-square" />
                                </div>
                            )}
                            {isActions.comment && (
                                <div className="actions-btn">
                                    <div className="action-square" />
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default Post;
