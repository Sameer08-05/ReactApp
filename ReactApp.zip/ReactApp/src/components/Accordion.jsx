import React, { useState, useRef, useEffect } from 'react';
import './Accordion.css';
import Post from './Post'

const postsData = [
    {
        id: 1,
        author: 'Cool guy',
        message:
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam urna orci, blandit eu ante nec, sodales vehicula nisi. Mauris vel nibh imperdiet, tempus lectus ac, faucibus quam. Praesent euismod congue cursus. Phasellus tincidunt sem vitae neque egestas, ut egestas justo venenatis.',
        isActions: {
            like: true,
            comment: true,
        },
        replies: [
            {
                id: 2,
                author: 'Someone',
                message: 'Hey @Cool guy, Lorem ipsum',
                isActions: {
                    like: true,
                    comment: false,
                }
            },
            {
                id: 3,
                author: 'Another User',
                message: 'Replying to @Someone in the thread!',
                isActions: {
                    like: true,
                    comment: true,
                },
            },
            {
                id: 4,
                author: 'Quiet User',
                message: 'Just jumping in without mentioning anyone.',
                isActions: {
                    like: false,
                    comment: true,
                },
            },
        ],
    },
    {
        id: 5,
        author: 'Second Poster',
        message: 'Here is a second root post with @Another User tagged.',
        replies: [
            {
                id: 6,
                author: 'Follower',
                message: 'Interesting thought @Second Poster!',
                isActions: {
                    like: true,
                    comment: true,
                },
            },
        ],
    },
];


function Accordion() {
    const [open, setOpen] = useState(false);
    const contentRef = useRef(null);
    const wrapperRef = useRef(null);

    const allAuthors = Array.from(
        new Set(
            postsData.flatMap((post) => [post.author, ...(post.replies?.map(r => r.author) || [])])
        )
    );

    useEffect(() => {
        const contentEl = contentRef.current;
        const wrapperEl = wrapperRef.current;

        if (!contentEl || !wrapperEl) return;

        if (open) {
            wrapperEl.style.overflow = 'hidden';

            const updateHeight = () => {
                wrapperEl.style.height = contentEl.scrollHeight + 'px';
                animationFrameId = requestAnimationFrame(updateHeight);
            };

            let animationFrameId = requestAnimationFrame(updateHeight);

            return () => {
                cancelAnimationFrame(animationFrameId);
                wrapperEl.style.height = 'auto';
                wrapperEl.style.overflow = 'visible';
            };
        } else {
            wrapperEl.style.height = contentEl.scrollHeight + 'px';
            wrapperEl.style.overflow = 'hidden';

            requestAnimationFrame(() => {
                wrapperEl.style.height = '0px';
            });
        }
    }, [open]);

    const selectedPost = postsData[0];

    return (
        <main className="App">
            <div className="container">

                <div className='header-parent' >
                    <a className='heading' >Prototype</a>
                    <a className='sub-heading' >Collapsable component</a>
                </div>
                <section className="dropdown" aria-expanded={open}>
                    <div className="post">
                        <div className="profile-box"></div>
                        <div className="post-message">
                            <a className="username">{selectedPost.author}</a>
                            <a className="message">{selectedPost.message}</a>

                            {selectedPost.isActions && (
                                <div className="post-footer">
                                    {selectedPost.isActions.like && (
                                        <div className="actions-btn">
                                            <div className="titled-square" />
                                        </div>
                                    )}
                                    {selectedPost.isActions.comment && (
                                        <div className="actions-btn">
                                            <div className="action-square" />
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>

                    <div
                        className="collapsible-content-wrapper"
                        ref={wrapperRef}
                        style={{
                            height: '0px',
                            overflow: 'hidden',
                            transition: 'height 0.5s ease',
                        }}
                    >
                        <div className="collapsible-content" ref={contentRef}>
                            {selectedPost.replies.map((reply, index) => {
                                const mentionsSomeone = allAuthors.some(author =>
                                    new RegExp(`@${author}\\b`).test(reply.message)
                                );

                                return (
                                    <React.Fragment key={reply.id}>
                                        {!mentionsSomeone && index !== 0 && <div className="dashed"></div>}
                                        {mentionsSomeone && <div style={{ marginTop: 8 }} />}
                                        <Post
                                            username={reply.author}
                                            message={reply.message}
                                            allAuthors={allAuthors}
                                            isActions={reply.isActions}
                                            isParentOpen={open}
                                        />
                                    </React.Fragment>
                                );
                            })}
                            <div className="dashed"></div>
                        </div>
                    </div>


                    {

                        open &&
                        <div className="dashed"></div>

                    }


                    <div className={`btn-parent ${open ? 'open' : 'closed'}`}>
                        <button
                            className="toggle-btn"
                            onClick={() => setOpen(!open)}
                        >
                            {open ? 'Close' : 'Open'}
                        </button>
                    </div>
                </section>
            </div>
        </main>
    );
}

export default Accordion;