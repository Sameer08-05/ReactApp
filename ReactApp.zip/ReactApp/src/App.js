import { BrowserRouter as Router, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import Themes from './pages/Themes';
import Accordion from './components/Accordion';

function NavigationButton() {
  const location = useLocation();
  const navigate = useNavigate();

  const isSamplePage = location.pathname === '/sample';

  return (
    <button
      onClick={() => navigate(isSamplePage ? '/' : '/sample')}
      style={{
        padding: '8px 12px',
        backgroundColor: '#007bff',
        color: '#fff',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
      }}
    >
      {isSamplePage ? 'Go to Accordian module' : 'Go to Theme changer module'}
    </button>
  );
}

function App() {
  return (
    <Router>
      <div style={{ position: 'absolute', top: 10, right: 10, zIndex: 1000 }}>
        <NavigationButton />
      </div>

      <Routes>
        <Route path="/" element={<Accordion />} />
        <Route path="/sample" element={<Themes />} />
      </Routes>
    </Router>
  );
}

export default App;
